import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _data = ActivityData();

  // Mengambil semua aktivitas
  List<ActivityModel> getActivities() {
    return _data.activities;
  }

  // Menambahkan aktivitas
  void addActivity(ActivityModel activity) {
    _data.activities.add(activity);
  }

  // Mengubah aktivitas
  void updateActivity(String id, String newName) {
    final index = _data.activities.indexWhere((activity) => activity.id == id);

    if (index != -1) {
      _data.activities[index].name = newName;
    }
  }

  // Menghapus aktivitas
  void deleteActivity(String id) {
    _data.activities.removeWhere((activity) => activity.id == id);
  }

  // Menambah counter
  void incrementCounter(String id) {
    final activity = _findActivity(id);
    if (activity != null) {
      activity.counter++;
    }
  }

  // Mengurangi counter
  void decrementCounter(String id) {
    final activity = _findActivity(id);

    if (activity != null && activity.counter > 0) {
      activity.counter--;
    }
  }

  // Reset counter
  void resetCounter(String id) {
    final activity = _findActivity(id);

    if (activity != null) {
      activity.counter = 0;
    }
  }

  ActivityModel? _findActivity(String id) {
    try {
      return _data.activities.firstWhere((activity) => activity.id == id);
    } catch (_) {
      return null;
    }
  }
}
