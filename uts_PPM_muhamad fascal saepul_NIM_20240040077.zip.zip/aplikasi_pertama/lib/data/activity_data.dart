import '../models/activity_model.dart';

class ActivityData {
  final List<ActivityModel> activities = [];
}
