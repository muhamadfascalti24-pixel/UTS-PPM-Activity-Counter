import 'package:flutter/material.dart';

import '../models/activity_model.dart';
import '../repositories/activity_repository.dart';

class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository = ActivityRepository();

  List<ActivityModel> get activities => _repository.getActivities();

  // Menambahkan aktivitas
  void addActivity(String name) {
    final activity = ActivityModel(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
    );

    _repository.addActivity(activity);
    notifyListeners();
  }

  // Mengedit nama aktivitas
  void updateActivity(String id, String newName) {
    _repository.updateActivity(id, newName);
    notifyListeners();
  }

  // Menghapus aktivitas
  void deleteActivity(String id) {
    _repository.deleteActivity(id);
    notifyListeners();
  }

  // Menambah counter
  void incrementCounter(String id) {
    _repository.incrementCounter(id);
    notifyListeners();
  }

  // Mengurangi counter
  void decrementCounter(String id) {
    _repository.decrementCounter(id);
    notifyListeners();
  }

  // Reset counter
  void resetCounter(String id) {
    _repository.resetCounter(id);
    notifyListeners();
  }
}
