import 'package:flutter/material.dart';

import 'viewmodels/activity_viewmodel.dart';
import 'views/home_view.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final activityViewModel = ActivityViewModel();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily Activity Counter',

      theme: ThemeData(primarySwatch: Colors.deepPurple, useMaterial3: true),

      home: HomeView(viewModel: activityViewModel),
    );
  }
}
