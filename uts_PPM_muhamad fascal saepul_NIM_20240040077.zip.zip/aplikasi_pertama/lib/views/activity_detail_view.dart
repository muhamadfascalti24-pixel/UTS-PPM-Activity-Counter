import 'package:flutter/material.dart';

import '../viewmodels/activity_viewmodel.dart';

class ActivityDetailView extends StatelessWidget {
  final ActivityViewModel viewModel;
  final String activityId;

  const ActivityDetailView({
    super.key,
    required this.viewModel,
    required this.activityId,
  });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: viewModel,
      builder: (context, child) {
        final matches = viewModel.activities.where(
          (item) => item.id == activityId,
        );

        if (matches.isEmpty) {
          return Scaffold(
            appBar: AppBar(title: const Text('Detail Aktivitas')),
            body: const Center(child: Text('Aktivitas tidak ditemukan')),
          );
        }

        final activity = matches.first;

        return Scaffold(
          backgroundColor: const Color(0xFFF5F3FF),
          appBar: AppBar(
            title: const Text('Detail Aktivitas'),
            backgroundColor: Colors.deepPurple,
            foregroundColor: Colors.white,
          ),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    activity.name,
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(30),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'Jumlah Aktivitas',
                          style: TextStyle(fontSize: 17),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          '${activity.counter}',
                          style: const TextStyle(
                            fontSize: 65,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepPurple,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton.filled(
                        onPressed: () {
                          viewModel.decrementCounter(activityId);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Counter dikurangi'),
                              duration: Duration(seconds: 1),
                            ),
                          );
                        },
                        icon: const Icon(Icons.remove),
                      ),
                      const SizedBox(width: 25),
                      IconButton.filled(
                        onPressed: () {
                          viewModel.incrementCounter(activityId);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Counter ditambahkan'),
                              duration: Duration(seconds: 1),
                            ),
                          );
                        },
                        icon: const Icon(Icons.add),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (dialogContext) => AlertDialog(
                            title: const Text('Reset Counter?'),
                            content: const Text(
                              'Apakah kamu yakin ingin mengembalikan '
                              'counter menjadi 0?',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(dialogContext, false),
                                child: const Text('Batal'),
                              ),
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(dialogContext, true),
                                child: const Text('Reset'),
                              ),
                            ],
                          ),
                        );

                        if (confirm == true && context.mounted) {
                          viewModel.resetCounter(activityId);
                        }
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('Reset Counter'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (dialogContext) => AlertDialog(
                            title: const Text('Hapus Aktivitas?'),
                            content: const Text(
                              'Aktivitas ini akan dihapus. Lanjutkan?',
                            ),
                            actions: [
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(dialogContext, false),
                                child: const Text('Batal'),
                              ),
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(dialogContext, true),
                                child: const Text('Hapus'),
                              ),
                            ],
                          ),
                        );

                        if (confirm == true && context.mounted) {
                          viewModel.deleteActivity(activityId);
                          Navigator.pop(context);

                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Aktivitas berhasil dihapus'),
                            ),
                          );
                        }
                      },
                      icon: const Icon(Icons.delete),
                      label: const Text('Hapus Aktivitas'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
